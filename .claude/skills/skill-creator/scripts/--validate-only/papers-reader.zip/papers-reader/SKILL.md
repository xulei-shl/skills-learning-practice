---
name: papers-reader
description: Specialized skill for reading and analyzing academic papers. Transforms PDF papers to markdown, generates structured summaries, and answers questions about paper content. Use this skill when users ask to read papers, analyze academic documents, or when PDF paper files are mentioned.
user-invocable: true
---

# Papers Reader

## Overview

This skill enables comprehensive reading and analysis of academic papers through a 4-step workflow: PDF conversion → Structured summarization → Interactive Q&A → Multi-dimensional analysis. It uses sub-agents to isolate complex analysis tasks from the main conversation, preventing context pollution while enabling deep academic insights.

## Triggering Conditions

This skill activates automatically when users mention paper-related keywords in Chinese or English contexts.

### Automatic Keyword Detection (Chinese Emphasis)

**Chinese Keywords (中文关键词):**
- 论文 (paper/thesis)
- 论文阅读 (paper reading)
- 分析论文 (analyze paper)
- 总结论文 (summarize paper)
- 解读论文 (interpret paper)
- 帮我读这篇论文 (help me read this paper)
- 这篇论文讲了什么 (what's this paper about)
- 如何理解这篇论文 (how to understand this paper)
- paper (in Chinese academic context)

**English Keywords:**
- paper reading
- read paper / read this paper
- analyze paper / paper analysis
- summarize paper / paper summary
- academic paper
- research paper

**Explicit Commands:**
- `/papers-read <path>` - Start complete paper reading workflow
- `/papers-analyze <path>` - Start with analysis focus

**File Context Triggers:**
When a PDF file path is mentioned alongside academic/research/reading context.

### Examples of Automatic Triggers

**Chinese Examples:**
```
用户: 我有一篇论文需要帮助理解
用户: 能帮我读一下这篇论文吗？./papers/transformer.pdf
用户: 这篇论文讲了什么内容？
用户: 请分析这篇学术论文
用户: 论文阅读: ./data/paper.pdf
用户: 如何总结这篇论文？
```

**English Examples:**
```
User: Can you read this paper for me?
User: Help me understand this research paper
User: Analyze paper: ./papers/transformer.pdf
User: Summarize this academic paper
```

**Explicit Command Examples:**
```
User: /papers-read ./papers/attention.pdf
User: /papers-analyze ./papers/gpt-paper.pdf
```

### Usage Notes

- This skill is optimized for Chinese academic environments
- English keywords also work perfectly
- File paths can be absolute or relative
- Both single files and batch directory processing are supported
- The skill automatically detects paper length and complexity to suggest appropriate depth of analysis

## Core Workflow

## Core Workflow

The papers reader skill follows a structured 4-stage workflow. Each stage can be executed independently or as part of a complete pipeline.

```
PDF Conversion → Structured Summary → Interactive Q&A → Multi-dimensional Analysis
     ↓                  ↓                    ↓                      ↓
   Scripts      paper-summarizer      Main Conversation   paper-analyzer
```

### Stage 1: PDF to Markdown Conversion

Use the `scripts/pdf2md.py` utility to convert PDF papers to clean markdown format.

**When to use this stage:**
- When user provides PDF paper files
- When batch processing multiple papers from a directory
- When only formatting cleanup is needed (skip summarization)

**Basic Usage:**
```bash
# Convert single PDF and auto-format
python scripts/pdf2md.py path/to/paper.pdf

# Convert to specific output location
python scripts/pdf2md.py path/to/paper.pdf -o path/to/output.md

# Batch convert all PDFs in a directory
python scripts/pdf2md.py path/to/papers/ -o path/to/outputs/
```

**Advanced Options:**
```bash
# Extract specific pages only
python scripts/pdf2md.py paper.pdf --pages 1-5,8,10-12

# Use parallel processing for batch jobs
python scripts/pdf2md.py papers/ --workers 8

# Convert without formatting (researchers may want raw conversion)
python scripts/pdf2md.py paper.pdf --pdf-only
```

**Conversion Features:**
- Removes extra spaces between Chinese characters
- Cleans up excessive newlines while preserving paragraph structure
- Automatically removes references section
- Handles various PDF encodings and formats
- Supports page range extraction for long papers

**Output:** Formatted markdown file at specified location (default: `outputs/`

### Stage 2: Structured Paper Summarization

Launch the `paper-summarizer` sub-agent to generate comprehensive, structured summaries.

**When to use this stage:**
- After PDF conversion is complete
- When user wants a structured overview of the paper
- For papers longer than 5 pages or 3000 words

**How to execute:**
1. Verify the converted markdown file exists
2. Launch sub-agent with paper-summarizer configuration
3. Pass the markdown file path as input
4. Sub-agent will generate `summary-{filename}.md`

**Sub-agent Configuration:**
```yaml
name: paper-summarizer
description: Specialized agent for academic paper summarization
tools: [Read, Edit, Write, Task]
model: sonnet
skills: []
```

**Process:**
1. Load `references/prompts/paper-summary.md` as system prompt
2. Read the converted markdown file
3. Generate structured summary with:
   - One-paragraph overview
   - Detailed section-by-section breakdown
   - Three critical questions answered
4. Save as `outputs/summary-{original_name}.md`
5. Return to main conversation

**Benefits of Sub-agent Isolation:**
- Large prompt (paper-summary.md) doesn't bloat main context
- Academic analysis is contained and doesn't leak into conversation
- Can run in background without blocking main workflow
- Summary quality is consistent and structured

### Stage 3: Interactive Q&A

Conduct interactive question-and-answer sessions about the paper in the main conversation.

**When to use this stage:**
- After summary is generated (or skipped if user prefers)
- When user has specific questions about paper content
- Throughout the conversation as follow-up questions arise

**Execution Method:**
All Q&A happens in the main conversation (not sub-agents) to:
- Maintain conversational context
- Allow follow-up questions
- Enable interactive exploration
- Build understanding progressively

**Responding to Questions:**
1. When user asks a question, Read the source markdown file
2. Search for relevant sections (can use grep patterns)
3. Provide detailed answers based on paper content
4. Optionally append Q&A to summary file:
   ```bash
   python scripts/update-summary.py --file outputs/summary-paper.md --question "用户的提问" --answer "你的回答" --section "Q&A"
   ```

**File Update Script:**
See `scripts/update-summary.py` for implementation. This script:
- Appends Q&A to specified section
- Maintains markdown formatting
- Prevents duplicate entries

### Stage 4: Multi-dimensional Analysis (Optional)

For high-quality papers, launch `paper-analyzer` sub-agent for deep multi-dimensional analysis.

**When to use this stage:**
- When paper is identified as highly significant
- When user requests deep analysis
- For literature reviews requiring critical evaluation
- For papers with novel methodologies or breakthrough results

**Sub-agent Configuration:**
```yaml
name: paper-analyzer
description: Specialized agent for multi-dimensional paper analysis
tools: [Read, Edit, Write, Task]
model: sonnet
skills: []
```

**Analysis Framework:**
1. Load `references/prompts/multi-dimension.md` as system prompt
2. Read both source paper and generated summary
3. Analyze across six dimensions:
   - Core contribution identification
   - Methodology analysis
   - Limitations and future work
   - Structured summary for literature reviews
   - Text structure and logical framework
   - Concept extraction
   - Critical thinking and evaluation
   - Deep philosophical analysis
   - Academic implications
   - Practical application insights

4. Save as `outputs/analysis-{original_name}.md`

**Triggering This Stage:**
Always ask user confirmation before launching:
> "This appears to be a high-quality paper. Would you like me to perform a multi-dimensional deep analysis? This will generate insights across six academic perspectives."

## Example Workflows

### Workflow 1: Complete Paper Analysis (Recommended)
```
User: Please read and analyze this paper: ./papers/transformer.pdf

Actions:
1. Convert PDF: python scripts/pdf2md.py ./papers/transformer.pdf
   → outputs/transformer.md

2. Offer summarization (detected 8,500 words)
   User: Yes, please summarize

3. Launch paper-summarizer sub-agent
   → outputs/summary-transformer.md (90 seconds)

4. Return to conversation
   User: What was their main innovation?

5. Read outputs/transformer.md, answer question
   Optionally append Q&A to summary

6. Offer deep analysis
   User: Yes, this looks promising

7. Launch paper-analyzer sub-agent
   → outputs/analysis-transformer.md (120 seconds)
```

### Workflow 2: Quick Conversion Only
```
User: Convert these papers to markdown without analysis

Actions:
1. Batch convert: python scripts/pdf2md.py ./papers/ --workers 8
   → outputs/*.md (all formatted)
2. Inform user completion, no summarization
```

### Workflow 3: Summary First, Q&A Follows
```
User: Summarize this paper for me

Actions:
1. Check if already converted, if not:
   python scripts/pdf2md.py paper.pdf

2. Launch paper-summarizer directly
   → outputs/summary-paper.md

3. User reviews summary
4. User asks follow-up questions
5. Answer in main conversation
```

## Key Design Principles

### Intelligent Triggering
The skill automatically activates based on:
- **Keywords**: Chinese and English paper-related terms
- **File context**: PDF files mentioned with academic intent
- **Explicit commands**: Direct skill invocation
- **Language detection**: Optimized for Chinese academic language patterns

### Progressive Disclosure
Each stage is optional and builds upon previous stages:
- Conversion needed for everything else
- Summary enables structured Q&A
- Deep analysis is optional and reserved for high-quality papers

### Context Isolation
Complex analysis tasks use sub-agents to prevent context pollution:
- Academic prompts don't bloat main conversation
- Analysis quality remains consistent
- Main conversation stays focused on user interaction

### File Organization
All outputs follow consistent naming:
- Converts: `{original}.md` or `outputs/{original}.md`
- Summaries: `summary-{original}.md`
- Analyses: `analysis-{original}.md`
- All stored in `outputs/` directory by default

## Resources

### scripts/
- `pdf2md.py` - PDF to markdown conversion with formatting
- `update-summary.py` - Append Q&A to summary files

### references/
- `prompts/paper-summary.md` - Structured summarization prompt
- `prompts/multi-dimension.md` - Deep analysis framework
- `workflows.md` - Detailed workflow documentation

### assets/
[Not currently used - can be removed or used for templates later]

---

**To use this skill:** Start with PDF conversion, then choose whether to generate summaries, conduct Q&A, or perform deep analysis based on user needs.
