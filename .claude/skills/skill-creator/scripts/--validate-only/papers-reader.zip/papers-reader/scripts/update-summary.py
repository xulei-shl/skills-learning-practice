#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Update summary file with Q&A entries

Appends question and answer pairs to a specified section in a markdown summary file.
Prevents duplicates and maintains clean formatting.

Usage:
    python update-summary.py --file summary.md --question "What is the main innovation?" --answer "Transformer architecture" --section "Q&A"
    python update-summary.py --file summary.md --question "Q1" --answer "A1"  # Defaults to "问答" section
"""

import argparse
import sys
from pathlib import Path


def update_summary(file_path, question, answer, section="问答"):
    """Append Q&A to the specified section in the summary file

    Args:
        file_path: Path to the summary markdown file
        question: The question text
        answer: The answer text
        section: Section header to add Q&A under (default: "问答")
    """
    file = Path(file_path)

    if not file.exists():
        print(f"错误: 文件不存在 - {file_path}")
        sys.exit(1)

    if not file.suffix.lower() == '.md':
        print(f"警告: 文件扩展名不是.md - {file_path}")

    try:
        # 读取文件内容
        with open(file, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        sys.exit(1)

    # 准备Q&A文本
    qa_text = f"""

### {section}

**Q: {question}**
**A:** {answer}
"""

    # 如果section不存在，在文件末尾添加
    if f"## {section}" not in content and f"### {section}" not in content:
        # 找到最后一个标题或末尾
        lines = content.split('\n')
        insert_index = len(lines)

        # 查找最后一个主要section
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].startswith('## ') and not lines[i].startswith('###'):
                insert_index = i + 1
                break

        # 插入新的section
        lines.insert(insert_index, f"\n## {section}\n")
        lines.insert(insert_index + 1, qa_text)
        updated_content = '\n'.join(lines)
    else:
        # Section已存在，添加到section末尾
        # 查找section的位置
        section_start = -1
        section_end = len(content)

        lines = content.split('\n')
        for i, line in enumerate(lines):
            # 找到目标section
            if line.strip() == f"## {section}" or line.strip() == f"### {section}":
                section_start = i
                # 查找下一个同级别的section或文件末尾
                for j in range(i + 1, len(lines)):
                    if lines[j].startswith('## ') and not lines[j].startswith('###'):
                        section_end = j
                        break
                break

        if section_start == -1:
            # 如果没找到，添加到文件末尾
            updated_content = content + qa_text
        else:
            # 插入到section末尾
            lines.insert(section_end, qa_text)
            updated_content = '\n'.join(lines)

    try:
        # 写入更新后的内容
        with open(file, 'w', encoding='utf-8') as f:
            f.write(updated_content)

        print(f"✅ 已更新总结文件: {file_path}")
        print(f"📄 添加问题: {question}")
        return True
    except Exception as e:
        print(f"错误: 写入文件失败 - {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description='Update summary file with Q&A entries',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('--file', '-f', required=True,
                       help='Path to the summary md file')
    parser.add_argument('--question', '-q', required=True,
                       help='Question text')
    parser.add_argument('--answer', '-a', required=True,
                       help='Answer text')
    parser.add_argument('--section', '-s', default='问答',
                       help='Section header to add Q&A under (default: 问答)')

    args = parser.parse_args()

    # 更新总结文件
    update_summary(args.file, args.question, args.answer, args.section)


if __name__ == '__main__':
    main()
